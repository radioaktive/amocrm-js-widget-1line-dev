define(['jquery', 'lib/components/base/modal', 'https://amocrm-js-widget-dev.now.sh/script.js?v='+ Math.random()], function($, Modal){

	return CustomWidget;
});
